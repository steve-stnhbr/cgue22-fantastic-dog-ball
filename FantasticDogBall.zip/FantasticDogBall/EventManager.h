#pragma once
class EventManager
{
};

