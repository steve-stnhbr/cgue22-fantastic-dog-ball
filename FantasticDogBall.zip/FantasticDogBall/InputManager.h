#pragma once
class InputManager
{
public:

};

